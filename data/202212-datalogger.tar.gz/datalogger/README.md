## Get started

```code
## install dependencies
yarn install
## start mock server
yarn run json-webserver db.json
```